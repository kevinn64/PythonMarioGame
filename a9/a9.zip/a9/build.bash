echo "Python 2.7.12"
echo "TYPE: 'python game.py' to run the program."